# VisioCoSM
# BELLEI | DE VITIS | SEVERI | VIGLIANISI
# A project developed for "smart robotics" - Unimore 2022
![image](https://user-images.githubusercontent.com/62468674/179230698-a9d59d63-f589-4b2e-9452-83a353da2392.png)



https://user-images.githubusercontent.com/62468674/179230847-1e221109-a13c-47ab-aaec-aeb6d6901e70.mp4

